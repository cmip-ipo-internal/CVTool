

experiment_template = {
    "activity_id": [],
    "additional_allowed_model_components": [],
    "experiment": "",
    "experiment_id": "",
    "parent_activity_id": [],
    "parent_experiment_id": [],
    "required_model_components": [],
    "sub_experiment_id": "none",
}