game = 1 

